package org.dykman.dexter.dexterity;

public class Dexterity
{
	public static final String DEXTERITY_SCHEMA_URL = 
		"http://dexter-xsl.googlecode.com/svn/trunk/schema/dexterity-1.0.xsd";
}
