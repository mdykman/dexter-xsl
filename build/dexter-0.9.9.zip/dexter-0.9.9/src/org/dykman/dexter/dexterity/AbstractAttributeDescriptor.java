package org.dykman.dexter.dexterity;

import org.dykman.dexter.descriptor.Descriptor;
import org.dykman.dexter.descriptor.PathDescriptor;

public class AbstractAttributeDescriptor extends PathDescriptor
{
	public AbstractAttributeDescriptor(Descriptor descriptor)
	{
		super(descriptor);
	}
	


}
