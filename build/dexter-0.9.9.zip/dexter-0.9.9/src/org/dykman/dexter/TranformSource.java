package org.dykman.dexter;

import javax.xml.transform.Source;

public class TranformSource implements Source
{

	public String getSystemId()
	{
		// TODO Auto-generated method stub
		return null;
	}

	public void setSystemId(String systemId)
	{
		// TODO Auto-generated method stub

	}
}
