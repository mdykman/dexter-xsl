package org.dykman.dexter;


public class DexterHaltException extends DexterException
{

	public DexterHaltException()
	{
		// TODO Auto-generated constructor stub
	}

	public DexterHaltException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DexterHaltException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DexterHaltException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
