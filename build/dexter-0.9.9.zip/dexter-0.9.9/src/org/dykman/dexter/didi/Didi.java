package org.dykman.dexter.didi;

public class Didi
{
	public static final String DIDI_SCHEMA_URL = 
		"http://dexter-xsl.googlecode.com/svn/trunk/schema/didi-1.0.xsd";

}
